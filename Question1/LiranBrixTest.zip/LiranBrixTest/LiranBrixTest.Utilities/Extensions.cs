﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public static class Extensions
{
    public static int ToSeconds(this int milliseconds)
    {
        return milliseconds / 1000;
    }

    public static int ToMilliseconds(this int seconds)
    {
        return seconds * 1000;
    }

    public static int ToMilliseconds(this byte seconds)
    {
        return seconds * 1000;
    }

    public static T Deserialize<T>(this byte[] bytes)
    {
        try
        {
            var bytesAsString = Encoding.UTF8.GetString(bytes);
            return JsonConvert.DeserializeObject<T>(bytesAsString);
        }
        catch
        {
            return default;
        }
    }

    #region Exception
    public static string GetAllMessages(this Exception exception)
    {
        var messages = exception.FromHierarchy(ex => ex.InnerException)
                                .Select(ex => ex.Message);
        return string.Join(Environment.NewLine, messages);
    }

    public static IEnumerable<TSource> FromHierarchy<TSource>(this TSource source, Func<TSource, TSource> nextItem, Func<TSource, bool> canContinue)
    {
        for (var current = source; canContinue(current); current = nextItem(current))
        {
            yield return current;
        }
    }

    public static IEnumerable<TSource> FromHierarchy<TSource>(this TSource source, Func<TSource, TSource> nextItem) where TSource : class
    {
        return FromHierarchy(source, nextItem, s => s != null);
    }
    #endregion
}
