﻿using System;

namespace LiranBrixTest.Models
{
    [Serializable]
    public sealed class CustomerQueueMessage
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }

        public CustomerQueueMessage(int customerId, string customerName)
        {
            CustomerID = customerId;
            CustomerName = customerName;
        }
    }
}
