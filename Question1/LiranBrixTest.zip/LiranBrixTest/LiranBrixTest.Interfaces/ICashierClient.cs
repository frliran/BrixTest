﻿using System;

namespace LiranBrixTest.Interfaces
{
    public interface ICashierClient : IDisposable
    {
        void Run();
    }
}
