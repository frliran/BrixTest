﻿namespace LiranBrixTest.Models
{
    public class ActiveCashierProcess
    {
        public int ProcessId;
        public string ProcessName;

        public ActiveCashierProcess(int processId, string processName)
        {
            ProcessId = processId;
            ProcessName = processName;
        }
    }
}
