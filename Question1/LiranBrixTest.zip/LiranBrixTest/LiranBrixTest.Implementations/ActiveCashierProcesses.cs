﻿using LiranBrixTest.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LiranBrixTest.Implementation
{
    public class ActiveCashierProcesses : IActiveCashierProcesses
    {
        /// <summary>
        /// Insert processId to database for process monitoring in case some processes were not closed
        /// </summary>
        /// <param name="processId"></param>
        /// <param name="processName"></param>
        /// <returns></returns>
        public async Task<int> InsertAsync(int processId, string processName)
        {
            //Save processId to database to monitor active processes
            return processId;
        }

        /// <summary>
        /// Remove processId from database once it was successfuly closed
        /// </summary>
        /// <param name="processId"></param>
        /// <returns></returns>
        public async Task DeleteAsync(int processId)
        {
            //Remove processId from database
        }

        /// <summary>
        /// Get all active processIds from database - those are processes that were not closed
        /// </summary>
        /// <returns></returns>
        public List<int> Get()
        {
            //Fetch processIds from database
            return new List<int>();
        }
    }
}
