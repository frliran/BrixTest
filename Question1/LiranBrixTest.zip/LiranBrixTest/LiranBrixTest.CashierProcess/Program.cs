﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using LiranBrixTest.Utilities;
using LiranBrixTest.Implementation;
using LiranBrixTest.Interfaces;
using Serilog;
using Serilog.Events;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;


namespace LiranBrixTest.CashierProcess
{
    //publish command: dotnet publish -c Release -r win10-x64
    class Program
    {
        private static ICashierClient cashierClient;
        private static IActiveCashierProcesses activeCashierProcesses;
        static int cashierProcessId;

        static async Task Main(string[] args)
        {
            ServiceProvider serviceProvider = null;
            try
            {
                IConfiguration configuration = BuildConfiguration();

                InitSerilog(LogEventLevel.Error);

                serviceProvider = SetDependencyInjection(configuration);
                AppDomain.CurrentDomain.ProcessExit += new EventHandler(ProcessExit);

                cashierClient = serviceProvider.GetService<ICashierClient>();
                cashierClient.Run();
            }
            catch (Exception ex)
            {
                Log.Logger.Error(ex, ex.GetAllMessages());
            }
            finally
            {
                activeCashierProcesses = serviceProvider.GetService<IActiveCashierProcesses>();
                cashierProcessId = await RegisterProcess();
                MonitorAgentProcess(args[0]);
            }
        }

        static IConfiguration BuildConfiguration()
        {
            return new ConfigurationBuilder()
                       .SetBasePath(AppContext.BaseDirectory)
                       .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "appsettings.json"), optional: false, reloadOnChange: true)
                       .Build();
        }

        static void InitSerilog(LogEventLevel logEventLevel)
        {
            Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Error()
            .MinimumLevel.Override("Microsoft", logEventLevel)
            .Enrich.FromLogContext()
            .WriteTo.File(Path.Combine(AppContext.BaseDirectory, Consts.Serilog.Path),
                            logEventLevel,
                            outputTemplate: Consts.Serilog.MessageTemplate,
                            rollingInterval: RollingInterval.Day,
                            rollOnFileSizeLimit: true,
                            //buffered: true,
                            shared: true)
            .CreateLogger();
        }

        static ServiceProvider SetDependencyInjection(IConfiguration configuration)
        {
            var serviceCollection = new ServiceCollection()
                .AddLogging()
                .AddSingleton(configuration)
                .AddSingleton<IActiveCashierProcesses, ActiveCashierProcesses>()
                .AddSingleton<ICashierClient, CashierClient>()
                .AddSingleton<IRabbitMQClient, RabbitMqClient>();

            serviceCollection.AddLogging(configure => configure.AddSerilog());

            return serviceCollection.BuildServiceProvider();
        }

        static async Task<int> RegisterProcess()
        {
            Process process = Process.GetCurrentProcess();
            return await activeCashierProcesses.InsertAsync(process.Id, process.ProcessName);
        }

        static void MonitorAgentProcess(string cashierManagerProcessId)
        {
            try
            {
                int.TryParse(cashierManagerProcessId, out int processId);
                Process process = Process.GetProcessById(processId);
                Task.Run(() => process.WaitForExit())
                    .ContinueWith(t => Environment.Exit(-1));
            }
            catch (Exception ex)
            {
                Log.Logger.Error(ex, ex.GetAllMessages());
            }
        }

        /// <summary>
        /// Kill all cashier processes when the cashier manager process shuts down - no to leave any open processes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void ProcessExit(object sender, EventArgs e)
        {
            activeCashierProcesses.DeleteAsync(cashierProcessId);
            cashierClient.Dispose();
        }
    }
}
