﻿using Microsoft.Extensions.Configuration;

namespace LiranBrixTest.Models
{
    public static class CashierProcessSettings
    {
        public static byte ProcessCount;
        public static ushort StartAttemptMillisecondsTimeout;
        public static byte AutoShutdownTimerInMinutes;
        public static bool AssignCorePerProcess;
        public static string ProcessFilePath;
        public static string ProcessFile;

        public static void Init(IConfigurationSection config)
        {
            try
            {
                byte.TryParse(config["ProcessCount"], out ProcessCount);
                ushort.TryParse(config["StartAttemptMillisecondsTimeout"], out StartAttemptMillisecondsTimeout);
                byte.TryParse(config["AutoShutdownTimerInMinutes"], out AutoShutdownTimerInMinutes);
                bool.TryParse(config["AssignCorePerProcess"], out AssignCorePerProcess);
                ProcessFilePath = config["ProcessFilePath"];
                ProcessFile = config["ProcessFile"];
            }
            catch { }
        }
    }
}
