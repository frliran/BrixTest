﻿namespace LiranBrixTest.Interfaces
{
    public interface ICashiersManager
    {
        void Run();
        void Stop();
    }
}
