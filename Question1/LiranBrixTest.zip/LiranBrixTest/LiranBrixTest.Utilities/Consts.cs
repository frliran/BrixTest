﻿namespace LiranBrixTest.Utilities
{
    public sealed class Consts
    {
        public const string CustomersQueue = "CustomersQueue ";

        public sealed class ArgumentsArray
        {
            //Number of const members in this class
            public const byte ArgumentsArrayLength = 2;
            public const byte ConsoleId = 0;
            public const byte AgentProcessId = 1;
        }

        public sealed class Serilog
        {
            public const string Path = "Serilog/log.txt";
            public const string MessageTemplate = "{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {Message:lj}{NewLine}{Exception}" +
                                                  "{NewLine}===================================================================================================={NewLine}";
        }
    }
}
