﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace LiranBrixTest.Interfaces
{
    public interface IActiveCashierProcesses
    {
        Task<int> InsertAsync(int processId, string processName);
        Task DeleteAsync(int processId);
        List<int> Get();
    }
}
