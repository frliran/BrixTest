﻿using LiranBrixTest.Implementation;
using LiranBrixTest.Interfaces;
using LiranBrixTest.Utilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Serilog.Events;
using System;
using System.Diagnostics;
using System.IO;

namespace LiranBrixTest.CashierManager
{
    //publish command: dotnet publish -c Release -r win10-x64
    class Program
    {
        private static ICashiersManager cashiersManager;

        static void Main(string[] args)
        {
            ServiceProvider serviceProvider = null;
            try
            {
                IConfiguration configuration = BuildConfiguration();

                InitSerilog(LogEventLevel.Error);

                serviceProvider = SetDependencyInjection(configuration);
                AppDomain.CurrentDomain.ProcessExit += new EventHandler(ProcessExit);

                KillOldCashierProcesses(serviceProvider);

                cashiersManager = serviceProvider.GetService<ICashiersManager>();
                cashiersManager.Run();
            }
            catch (Exception ex)
            {
                Log.Logger.Error(ex, ex.GetAllMessages());
            }
        }

        static IConfiguration BuildConfiguration()
        {
            return new ConfigurationBuilder()
                       .SetBasePath(AppContext.BaseDirectory)
                       .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "appsettings.json"), optional: false, reloadOnChange: true)
                       .Build();
        }

        static void InitSerilog(LogEventLevel logEventLevel)
        {
            Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Error()
            .MinimumLevel.Override("Microsoft", logEventLevel)
            .Enrich.FromLogContext()
            .WriteTo.File(Path.Combine(AppContext.BaseDirectory, Consts.Serilog.Path),
                            logEventLevel,
                            outputTemplate: Consts.Serilog.MessageTemplate,
                            rollingInterval: RollingInterval.Day,
                            rollOnFileSizeLimit: true,
                            //buffered: true,
                            shared: true)
            .CreateLogger();
        }

        static ServiceProvider SetDependencyInjection(IConfiguration configuration)
        {
            var serviceCollection = new ServiceCollection()
                .AddLogging()
                .AddSingleton(configuration)
                .AddSingleton<IActiveCashierProcesses, ActiveCashierProcesses>()
                .AddSingleton<ICashiersManager, CashiersManager>()
                .AddSingleton<IRabbitMQClient, RabbitMqClient>();

            serviceCollection.AddLogging(configure => configure.AddSerilog());

            return serviceCollection.BuildServiceProvider();
        }

        static void ProcessExit(object sender, EventArgs e)
        {
            cashiersManager.Stop();
        }

        /// <summary>
        /// If there are any open cashier processes open - kill them before opening new ones.
        /// </summary>
        /// <param name="services"></param>
        static void KillOldCashierProcesses(ServiceProvider services)
        {
            IActiveCashierProcesses activeCashierProcesses = services.GetService<IActiveCashierProcesses>();

            var cashierProcesses = activeCashierProcesses.Get();
            foreach (int processId in cashierProcesses)
            {
                try
                {
                    Process cashierProcess = null;
                    try
                    {
                        cashierProcess = Process.GetProcessById(processId);
                    }
                    catch
                    {
                        activeCashierProcesses.DeleteAsync(processId);
                        continue;
                    }

                    cashierProcess.Kill();
                    activeCashierProcesses.DeleteAsync(processId);
                }
                catch (Exception ex)
                {
                    Log.Error(ex, ex.GetAllMessages());
                }
            }
        }
    }
}
