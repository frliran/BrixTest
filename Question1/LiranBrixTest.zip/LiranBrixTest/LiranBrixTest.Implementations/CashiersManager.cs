using LiranBrixTest.Interfaces;
using LiranBrixTest.Models;
using LiranBrixTest.Utilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace LiranBrixTest.Implementation
{
    public class CashiersManager : ICashiersManager
    {
        #region Members
        private bool cancelProcess;
        private List<Process> cashierProcesses;
        private System.Timers.Timer cashierProcessesMonitor;

        readonly ILogger<CashiersManager> logger;
        readonly IRabbitMQClient rabbitMQClient;
        readonly IActiveCashierProcesses activeCashierProcesses;
        #endregion

        public CashiersManager(IRabbitMQClient rabbitMQClient, IActiveCashierProcesses activeCashierProcesses,
                               IConfiguration config, ILogger<CashiersManager> logger)
        {
            this.rabbitMQClient = rabbitMQClient;
            this.activeCashierProcesses = activeCashierProcesses;
            this.logger = logger;

            CashierProcessSettings.Init(config.GetSection("CashierProcessSettings"));
            InitCashierProcessesMonitorTimer();
            cashierProcesses = new List<Process>(CashierProcessSettings.ProcessCount);
        }

        private void InitCashierProcessesMonitorTimer()
        {
            cashierProcessesMonitor = new System.Timers.Timer
            {
                AutoReset = false,
            };

            if (CashierProcessSettings.AutoShutdownTimerInMinutes > 0)
            {
                cashierProcessesMonitor.Elapsed += (object source, System.Timers.ElapsedEventArgs e) => StopCashierProcesses();
                cashierProcessesMonitor.Interval = CashierProcessSettings.AutoShutdownTimerInMinutes.ToMilliseconds();
            }
        }

        #region Upload Sessions
        public void Run()
        {
            cashierProcessesMonitor.Stop();

            while (!rabbitMQClient.IsReady)
                Task.Delay(10).Wait();

            rabbitMQClient.InitQueues(Consts.CustomersQueue);

            cancelProcess = false;

            StartCashierProcesses().Wait(CashierProcessSettings.StartAttemptMillisecondsTimeout);

            if (!cashierProcesses.Any())
            {
                logger.LogError("Cashier processes faild to start");
                return;
            }

            int customerId = 0;
            while (!cancelProcess)
            {
                try
                {
                    rabbitMQClient.Send(Consts.CustomersQueue, new CustomerQueueMessage(++customerId, $"Customer {customerId}"));
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, ex.GetAllMessages());
                    throw;
                }
                finally
                {
                    Task.Delay(1000).Wait();
                }
            }

            cashierProcessesMonitor.Start();
        }

        private Task StartCashierProcesses()
        {
            //StopCashierProcesses();
            //LoadCashierProcessConfiguration(uploadMethod);

            return Task.Run(() =>
            {
                if (cashierProcesses.Any())
                    return;

                string currentProcessId = $"{Process.GetCurrentProcess().Id}";
                for (sbyte i = 0; i < CashierProcessSettings.ProcessCount; i++)
                    RunProcess(GetProcessStartInfo(currentProcessId), i);
            });
        }

        private ProcessStartInfo GetProcessStartInfo(string arguments)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                UseShellExecute = false,
                RedirectStandardOutput = true,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };

            startInfo.WorkingDirectory = CashierProcessSettings.ProcessFilePath;
            startInfo.FileName = "dotnet";
            startInfo.Arguments = $"{CashierProcessSettings.ProcessFile} {arguments}";
            return startInfo;
        }

        private void RunProcess(ProcessStartInfo startInfo, sbyte consoleId)
        {
            var process = new Process { StartInfo = startInfo };

            process.Start();

            if (CashierProcessSettings.AssignCorePerProcess)
            {
                try
                {
                    ProcessThreadCollection threads = process.Threads;
                    threads[0].IdealProcessor = consoleId + 1;
                    threads[0].ProcessorAffinity = new IntPtr(consoleId + 1); // 0x0001 - 0x0005;
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, ex.GetAllMessages());
                }
            }

            Task.Run(() => {
                while (!process.StandardOutput.EndOfStream)
                {
                    string line = process.StandardOutput.ReadLine();
                    Console.WriteLine(line);
                }
            });

            if (!process.HasExited)
                cashierProcesses.Add(process);
        }
        #endregion

        public void Stop()
        {
            try
            {
                cancelProcess = true;
                StopCashierProcesses();
                rabbitMQClient.InitQueues(Consts.CustomersQueue);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
        }

        private void StopCashierProcesses()
        {
            cashierProcesses.ForEach(process =>
            {
                try
                {
                    process.Kill();
                    activeCashierProcesses.DeleteAsync(process.Id);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, ex.GetAllMessages());
                }
            });
            cashierProcesses.Clear();
        }
    }
}