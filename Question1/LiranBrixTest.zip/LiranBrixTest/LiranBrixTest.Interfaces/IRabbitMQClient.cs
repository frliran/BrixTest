﻿using RabbitMQ.Client.Events;
using System;

namespace LiranBrixTest.Interfaces
{
    public interface IRabbitMQClient
    {
        bool IsReady { get; }
        void InitQueues(params string[] queueNames);
        void Send<T>(string queueName, T message);
        bool HasMessages(string queueName);
        T Receive<T>(string queueName);
        string Subscribe(string queueName, EventHandler<BasicDeliverEventArgs> receivedHandler);
        void BasicAck(ulong deliveryTag);
        void Unsubscribe(string consumerTag);
    }
}
