﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using LiranBrixTest.Interfaces;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Threading.Tasks;

namespace LiranBrixTest.Implementation
{
    public sealed class RabbitMqClient : IRabbitMQClient, IDisposable
    {
        private readonly ILogger<RabbitMqClient> logger;
        private IModel channel;
        private IConnection connection;
        private Task initTask;

        public RabbitMqClient(IConfiguration config, ILogger<RabbitMqClient> logger)
        {
            this.logger = logger;
            initTask = InitRabbitMQ(new RabbitMQConfig(config.GetSection("RabbitMQConfig")));
        }

        public bool IsReady
        {
            get
            {
                initTask.Wait(2000);
                return initTask.IsCompletedSuccessfully;
            }
        }

        private Task InitRabbitMQ(RabbitMQConfig rabbitConfig)
        {
            return Task.Run(() =>
            {
                while (true)
                {
                    try
                    {
                        ConnectionFactory factory = new ConnectionFactory()
                        {
                            Uri = new UriBuilder(rabbitConfig.Uri).Uri
                        };
                        connection = factory.CreateConnection();
                        channel = connection.CreateModel();
                        channel.BasicQos(0, 1, false);

                        break;
                    }
                    catch (Exception ex)
                    {
                        logger.LogError(ex, ex.GetAllMessages());
                        Task.Delay(rabbitConfig.InitWaitIntervalSeconds * 1000).Wait();
                    }
                }
            });
        }

        public void InitQueues(params string[] queueNames)
        {
            foreach (string queueName in queueNames)
            {
                try
                {
                    var queue = channel.QueueDeclare(
                                            queue: queueName,
                                            durable: false,
                                            exclusive: false,
                                            autoDelete: false
                                        );

                    if (queue.MessageCount > 0)
                        channel.QueuePurge(queueName);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, ex.GetAllMessages());
                }
            }
        }

        public void Send<T>(string queueName, T message)
        {
            try
            {
                var body = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(message));
                if (body != null)
                {
                    channel.BasicPublish(
                        exchange: string.Empty,
                        routingKey: queueName,
                        basicProperties: null,
                        body: body
                    );
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
        }

        public bool HasMessages(string queueName)
        {
            return channel.MessageCount(queueName) > 0;
        }

        public T Receive<T>(string queueName)
        {
            try
            {
                BasicGetResult result = channel.BasicGet(queueName, false);
                if (result != null)
                {
                    IBasicProperties props = result.BasicProperties;
                    var message = result.Body.Deserialize<T>();
                    channel.BasicAck(result.DeliveryTag, false);

                    return message;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
            return default;
        }

        public string Subscribe(string queueName, EventHandler<BasicDeliverEventArgs> receivedHandler)
        {
            try
            {
                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += receivedHandler;
                return channel.BasicConsume(
                    queue: queueName,
                    autoAck: false,
                    consumer: consumer
                );
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
                return null;
            }
        }

        public void BasicAck(ulong deliveryTag)
        {
            try
            {
                channel.BasicAck(deliveryTag, false);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
        }

        public void Unsubscribe(string consumerTag)
        {
            try
            {
                channel.BasicCancel(consumerTag);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
        }

        public void Dispose()
        {
            try
            {
                connection.Dispose();
                channel.Dispose();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
        }
    }

    public sealed class RabbitMQConfig
    {
        public string Uri;
        public byte InitWaitIntervalSeconds;

        public RabbitMQConfig(IConfigurationSection config)
        {
            Uri = config["Uri"];
            if (!byte.TryParse(config["InitWaitIntervalSeconds"], out InitWaitIntervalSeconds));
                InitWaitIntervalSeconds = 10;
        }
    }
}
