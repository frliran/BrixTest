﻿using LiranBrixTest.Interfaces;
using LiranBrixTest.Models;
using LiranBrixTest.Utilities;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client.Events;
using System;
using System.Threading.Tasks;

namespace LiranBrixTest.Implementation
{
    public sealed class CashierClient : ICashierClient
    {
        private string consumerTag;
        private readonly IRabbitMQClient rabbitMQClient;
        private readonly ILogger<CashierClient> logger;

        public CashierClient(IRabbitMQClient rabbitMQClient, ILogger<CashierClient> logger)
        {
            this.rabbitMQClient = rabbitMQClient;
            this.logger = logger;
        }

        public void Run()
        {
            while (!rabbitMQClient.IsReady)
                Task.Delay(10).Wait();

            consumerTag = rabbitMQClient.Subscribe(Consts.CustomersQueue, UploadFile);
        }

        private void UploadFile(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                CustomerQueueMessage message = e.Body.Deserialize<CustomerQueueMessage>();

                DateTime start = DateTime.Now;
                
                //Handle customer
                Random waitTime = new Random();
                int wait = waitTime.Next(1, 5).ToMilliseconds();
                Task.Delay(wait).Wait();

                DateTime end = DateTime.Now;

                rabbitMQClient.BasicAck(e.DeliveryTag);

                Console.WriteLine($"CustomerID: {message.CustomerID}, CustomerName: {message.CustomerName}, Start: {start.ToString("HH:mm:ss")}, end: {end.ToString("HH:mm:ss")}, HandleTime: {wait.ToSeconds()} seconds");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
        }

        public void Dispose()
        {
            try
            {
                rabbitMQClient.Unsubscribe(consumerTag);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.GetAllMessages());
            }
        }
    }
}
